<!-- Footer -->
<div id ="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <span>© Copyright 2022 News | Powered by <a href="#">Prothom alo English</a> Developer  : PWAD-53- Md. Abusaid</span>
            </div>
        </div>
    </div>
</div>
<!-- /Footer -->
</body>
</html>
